# Assemble bootloader
nasm -f bin boot.asm -o boot.bin

# Compile kernel
i686-elf-gcc -ffreestanding -c kernel.cpp -o kernel.o

# Link kernel
i686-elf-ld -o kernel.bin -T linker.ld kernel.o

# Combine bootloader and kernel
cat boot.bin kernel.bin > os-image.bin

# Run in QEMU
qemu-system-i386 -drive format=raw,file=os-image.bin

